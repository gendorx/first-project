<?php

define('MYSQL_HOST', 'localhost');
define('MYSQL_DATABASE', 'eban');
define('MYSQL_USER', 'eban');
define('MYSQL_PASSWORD', 'Zxc123@!123');
