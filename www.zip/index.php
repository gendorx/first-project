<?php
include './modules/database.php';
include './configs/global.php';

Database::connect(MYSQL_USER, MYSQL_PASSWORD, MYSQL_HOST, MYSQL_DATABASE);

// Getting stats albums from db

class MainController
{
    private $years;

    public function controller(): void
    {
        $sth = Database::$db->Prepare(
            "SELECT YEAR(released) AS year, COUNT(*) AS count_songs " . // attributes
                "FROM albums " . // table
                "WHERE released IS NOT NULL " . // condition
                "GROUP BY year " . // group
                "ORDER BY year ASC" // sort
        );

        $sth->execute();
        $this->years = $sth->fetchAll(PDO::FETCH_CLASS);
    }

    public function main(): void
    { ?>
        <table>
            <thead>
                <tr>
                    <th>Год</th>
                    <th>Количество</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($this->years as $year) { ?>
                    <tr>
                        <td> <?= htmlspecialchars($year->year) ?> </td>
                        <td> <?= htmlspecialchars($year->count_songs) ?> </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
<?php
    }
}

$controller = new MainController;

$controller->controller();

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Статистика</title>

    <style>
        * {
            margin: 0;
            padding: 0;
        }

        td,
        th {
            border: 1px solid black;
            padding: 1rem;
            margin: 0;
            display: table-cell;
        }
    </style>
</head>

<body>
    <?php $controller->main() ?>
</body>

</html>